<?php

	require('dbfunclibrary.php');
	
	clearDB();
	
	header("Location: index.php");

?>